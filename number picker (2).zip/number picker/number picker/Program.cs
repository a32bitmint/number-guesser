﻿//Simple number guesser written in C#
// Generate the number
Random rnd = new Random();
int rand = rnd.Next(1, 100);
//DEBUG: print the number into the console
Console.WriteLine(rand);
//Throw the prompt into console; also contains main loop
MainLoop:
Console.WriteLine("Guess a number from 1 to 100.");
int number = int.Parse(Console.ReadLine());
if (number == rand)
{
    Console.WriteLine($"You guessed {number}... and won! Congrats!");
}
else
{
    if (number > rand) //determine if number is too high
    {
        Console.WriteLine("Your guess was too high!");
        goto MainLoop;
    }
    if (number < rand) //determine if number is too low
    {
        Console.WriteLine("Your guess was too low!");
        goto MainLoop;
    }
}