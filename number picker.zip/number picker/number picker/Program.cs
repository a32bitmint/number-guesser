﻿//Simple number guesser written in C#
// Generate the number
Random rnd = new Random();
int rand = rnd.Next(1, 100);
//DEBUG: print the number into the console
Console.WriteLine(rand);
//Throw the prompt into console
Console.WriteLine("Guess a number from 1 to 100.");
int number = int.Parse(Console.ReadLine());
if (number == rand)
{
    Console.WriteLine($"You guessed {number}... and won! Congrats!");
}
else
{
    Console.WriteLine($"You guessed {number}... but unfortunately, you lost. Sorry!");
    Console.WriteLine("Try again!");
}